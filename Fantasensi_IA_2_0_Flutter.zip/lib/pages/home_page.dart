
import 'package:flutter/material.dart';
import '../services/sensi_ia.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  Map<String, int>? sensi;

  void gerar() {
    setState(() {
      sensi = SensiIA.gerarSensiIA();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Fantasensi IA 2.0")),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            sensi == null
                ? const Text("Clique para gerar uma Sensi IA")
                : Text(
                    "Geral: ${sensi!["geral"]}\n"
                    "Red Dot: ${sensi!["redDot"]}\n"
                    "2x: ${sensi!["2x"]}\n"
                    "4x: ${sensi!["4x"]}\n"
                    "AWM: ${sensi!["awm"]}",
                    textAlign: TextAlign.center,
                    style: const TextStyle(fontSize: 18),
                  ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: gerar,
              child: const Text("Gerar com IA"),
            )
          ],
        ),
      ),
    );
  }
}
