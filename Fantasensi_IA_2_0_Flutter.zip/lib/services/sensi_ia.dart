
import 'dart:math';

class SensiIA {
  static final Random _r = Random();

  static final List<Map<String, int>> database = [
    {"geral": 90, "redDot": 85, "2x": 80, "4x": 70, "awm": 60},
    {"geral": 100, "redDot": 95, "2x": 90, "4x": 80, "awm": 65},
    {"geral": 110, "redDot": 105, "2x": 100, "4x": 90, "awm": 70},
    {"geral": 120, "redDot": 115, "2x": 110, "4x": 95, "awm": 75},
  ];

  static Map<String, int> gerarSensiIA() {
    final base = database[_r.nextInt(database.length)];

    int variacao(int v) => v + _r.nextInt(7) - 3;

    return {
      "geral": variacao(base["geral"]!),
      "redDot": variacao(base["redDot"]!),
      "2x": variacao(base["2x"]!),
      "4x": variacao(base["4x"]!),
      "awm": variacao(base["awm"]!),
    };
  }
}
